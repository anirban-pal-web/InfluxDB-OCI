import boto3
import os

def handler(event, context):
    ssm = boto3.client('ssm')
    instance_id = os.environ['DR_INSTANCE_ID']

    ssm.send_command(
        InstanceIds=[instance_id],
        DocumentName="AWS-RunShellScript",
        Parameters={
            "commands": [
                "bash /home/ubuntu/restore-dr.sh"
            ]
        }
    )

    return {"status": "restore triggered"}

